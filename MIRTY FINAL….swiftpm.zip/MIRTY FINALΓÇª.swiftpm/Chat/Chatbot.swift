import Foundation


func getBotResponse(message: String) -> String {
    let tempMessage = message.lowercased()
    
    if tempMessage.contains("hi") {
        return "Hey there!"
    } else if tempMessage.contains("bye") {
        return "Talk to you later!"
    } else if tempMessage.contains("how are you") {
        return "I'm fine, how about you?"
    } else if tempMessage.contains("i am zesty"){
        return "slayy queeen 💅"
    }else if tempMessage.contains("jintao"){
            return "grasshead / uncle raymond"
    } else {
        return "That's cool."
    }
}


