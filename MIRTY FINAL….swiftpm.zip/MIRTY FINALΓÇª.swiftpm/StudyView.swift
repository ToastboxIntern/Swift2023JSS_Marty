import SwiftUI
import ExplorersApp

struct StudyView: View {
    
    @StateObject var appData = AppData.shared
    
    var body: some View {
        Text("Text")
        
    }
}

struct StudyView_Previews: PreviewProvider {
    static var previews: some View {
        ExplorersApp(.portrait){
            StudyView()
        }
        
    }
}



