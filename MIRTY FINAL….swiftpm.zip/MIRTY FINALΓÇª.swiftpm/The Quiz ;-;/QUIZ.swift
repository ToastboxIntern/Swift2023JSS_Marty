import SwiftUI


struct QuizAppApp: App {
    var body: some Scene {
        WindowGroup {
            WelcomeView()
        }
    }
}


