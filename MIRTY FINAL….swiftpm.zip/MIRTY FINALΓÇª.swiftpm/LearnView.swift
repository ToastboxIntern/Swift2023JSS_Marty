import SwiftUI
import ExplorersApp
struct LearnView: View {
    
    var body: some View {
        ZStack{
            Color(red:255/255, green:128/255, blue:129/255)
            Image("L").resizable().scaledToFit().offset(y:-55)
            TabBarView().offset(y:480)  
            
            VStack {
                Group{
                    VStack{
                        Button{
                            AppData.shared.currentView=8 
                        }label:{
                            Image("L1").resizable().scaledToFit().padding().frame(maxWidth:270)
                                .background(Color(red:255/255, green:239/255, blue:134/255), in: RoundedRectangle(cornerRadius: 15))
                        }.offset(x:210, y:-220)
                        
                        Button{
                            AppData.shared.currentView=9
                        }label:{
                            Image("L2").resizable().scaledToFit().padding().frame(maxWidth:270)
                                .background(Color(red:255/255, green:239/255, blue:134/255), in: RoundedRectangle(cornerRadius: 15))
                        }.offset(x:210, y:-140)
                        
                        Button{
                            AppData.shared.currentView=9
                        }label:{
                            Text("Take Flashcard Quiz").padding().frame(maxWidth:400).font(.title).foregroundColor(.white).bold()
                        }.offset(x:4, y:-30)
                        
                    }
                }
                HStack{
                    
                }
            }
            
            
            
        }
    }
    
}

struct LearnView_Previews: PreviewProvider {
    static var previews: some View {
        ExplorersApp(.portrait){
            LearnView()
        }
        
    }
}

